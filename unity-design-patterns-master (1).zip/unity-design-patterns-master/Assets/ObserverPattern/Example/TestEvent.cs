﻿namespace NG.Patterns.Structure.ObserverPatternExample
{
    public enum TestEvent
    {
        JUMP,
        CHANGE_COLOR
    }
}
