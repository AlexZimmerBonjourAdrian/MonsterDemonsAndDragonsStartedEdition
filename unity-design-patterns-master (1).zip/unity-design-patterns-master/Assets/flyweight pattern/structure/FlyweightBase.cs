namespace NG.Flyweight.Structure
{
    public abstract class FlyweightBase
    {
        public abstract void StatefulOperation(object obj);
    }
}
