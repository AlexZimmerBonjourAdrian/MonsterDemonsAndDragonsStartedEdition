# 2D Shooting
Project files for our tutorial on 2D Shooting in Unity.

The asset pack used for the environment is Warped Caves which you can download [here](https://www.assetstore.unity3d.com/#!/content/103250?aid=1101lPGj).

Check out our [YouTube Channel](http://youtube.com/brackeys) for more tutorials.