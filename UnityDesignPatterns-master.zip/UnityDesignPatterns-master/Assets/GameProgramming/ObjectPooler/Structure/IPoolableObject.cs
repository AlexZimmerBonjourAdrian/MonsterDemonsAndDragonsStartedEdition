﻿namespace Patterns
{
    public interface IPoolableObject
    {
        void Restart();
    }
}