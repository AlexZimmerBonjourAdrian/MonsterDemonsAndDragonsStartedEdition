﻿using UnityEngine;

namespace PrefabPool
{
    public class APooled : MonoBehaviour
    {
    }
}