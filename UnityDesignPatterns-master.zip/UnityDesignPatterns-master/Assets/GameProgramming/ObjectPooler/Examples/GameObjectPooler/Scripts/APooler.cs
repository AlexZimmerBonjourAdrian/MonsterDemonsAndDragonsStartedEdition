﻿using Patterns;

namespace PrefabPool
{
    public class APooler : PrefabPooler
    {
    }
}